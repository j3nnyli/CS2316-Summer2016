# Jenny Li
# GTID 903108178
# jli639@gatech.edu
# I worked on this assignment alone using only this semester's course materials.

import csv
import copy

def takeitIn(fileName1, fileName2):

    # first open fileName1 and read into a list, row by row
    lines1 = []
    f1 = open(fileName1)
    read1 = csv.reader(f1, delimiter=",")
    for row in read1:
        lines1.append(row)
    f1.close()

    # same for fileName2
    lines2 = []
    f2 = open(fileName2)
    read2 = csv.reader(f2, delimiter=",")
    for row in read2:
        lines2.append(row)
    f2.close()

    # if an element in a list in lines1 == "", replace it with the element with the same index in lines2
    for i in range(len(lines1)):
        for j in range(len(lines1[i])):
            if lines1[i][j] == "":
                lines1[i][j] = lines2[i][j]
    
    # if an element in a list in lines2 == "", replace it with the element with the same index in lines1
    for i in range(len(lines2)):
        for j in range(len(lines2[i])):
            if lines2[i][j] == "":
                lines2[i][j] = lines1[i][j]

    # now the contents of lines1 == contents of lines2
    # if a cell is still "", replace it with "-"
    for i in range(len(lines1)-1):
        for j in range(len(lines1[i])-1):
            if lines1[i][j] == "":
                lines1[i][j] = "-"
    
    # write lists in lines1 to new file burgertime.csv, row by row
    f3 = open("burgertime.csv", "w", newline="")
    w3 = csv.writer(f3)
    for sublist in lines1:
        w3.writerow(sublist)
    f3.close()

    # return the merged list
    return lines1

def sorter(mergedList):
    
    #should use the output of takeitIn as the argument

    # take out the first column in mergedList temporarily
    tempCol = mergedList[0]
    mergedList.remove(mergedList[0])

    # take out Bob's column temporarily (so Bob is always at the top later)
    bobCol = []
    for i in range(len(mergedList)-1):
        if mergedList[i][0] == "Bob":
            bobCol = copy.deepcopy(mergedList[i])
            mergedList.remove(mergedList[i])

    # sort by position
    # sends those with position - to bottom
    positionSortOrder = {"Owner":1, "Wizard":2, "Cashier":3, "Cook":4, "Stockperson":5, "-":6}
    mergedList.sort(key=lambda position:positionSortOrder[position[1]])

    # sort by age, maintaining the sorted positions
    # ignores if age is -
    for i in range(len(mergedList)-1):
        if mergedList[i][1] == mergedList[i+1][1]:
            if mergedList[i][2] != "-" and mergedList[i+1][2] != "-":
                if float(mergedList[i][2]) < float(mergedList[i+1][2]):
                    temp = copy.deepcopy(mergedList[i])
                    mergedList[i] = mergedList[i+1]
                    mergedList[i+1] = temp
    
    # sort by hire date, maintaining the sorted positions and ages
    for i in range(len(mergedList)-1):
        if mergedList[i][1] == mergedList[i+1][1] and mergedList[i][2] == mergedList[i+1][2]:
            if float(mergedList[i][3]) < float(mergedList[i+1][3]):
                temp = mergedList[i]
                mergedList[i] = mergedList[i+1]
                mergedList[i+1] = temp
    
    # add first column and Bob's column back to list
    mergedList = [tempCol] + [bobCol] + mergedList
    
    # create Rank column
    rank = []
    for i in range(1, len(mergedList)):
        rank.append(i)
    rank = ["Rank"] + rank
    
    # add ranks to each nested list
    for i in range(len(mergedList)):
        mergedList[i] = [rank[i]] + mergedList[i]

    # return list
    return mergedList

def bestEmployee(year):

    # determine which index in each nested list corresponds with the input year
    searchIndex = 0
    if year == 2015:
        searchIndex = 5
    elif year == 2016:
        searchIndex = 6
    elif year == 2014:
        searchIndex = 7
    elif year == 2013:
        searchIndex = 8

    # search through the nested lists in the sorted list to find highest hours for that year
    # along with employee name and rank
    mergedList = sorter(takeitIn("dunwoody.csv", "oldfourthward.csv"))
    hours = 0
    employee = ""
    rank = 0
    for i in range(1, len(mergedList)):
        if mergedList[i][searchIndex] != "-":
            if float(mergedList[i][searchIndex]) > hours:
                hours = int(mergedList[i][searchIndex])
                employee = mergedList[i][1]
                rank = mergedList[i][0]

    # print statement
    print("The person who worked the most hours in", year, "was", employee + ",", "ranked", str(rank) + "th overall, with", str(hours), "hours in", year, "year.")
