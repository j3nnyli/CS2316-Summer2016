# Jenny Li
# GTID 903108178
# jli639@gatech.edu
# I worked on this assignment alone using only this semester's course materials.

from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import csv
import string

class HW04():
    
    def __init__(self, rootWin):
        
        self.root = rootWin
        self.GUISetup()

    def GUISetup(self):
        
        # title
        self.root.title("MLB Stats")

        # Select File button
        self.selectFileButton = Button(self.root, text="Select File", width=20, command=self.fileSelect)
        self.selectFileButton.grid(row=0, column=0)

        # Enter a Player Name button
        self.playerNameButton = Button(self.root, text="Enter a Player Name", width=20, command=self.searcher)
        self.playerNameButton.grid(row=1, column=0)

        # entry to right of Select File button
        self.entrySelectFile = Entry(self.root, width=60, state="readonly")
        self.entrySelectFile.grid(row=0, column=1, columnspan=10) #experiment with columnspan

        # entry to right of Enter a Player Name button
        self.entryPlayerName = Entry(self.root, width=60)
        self.entryPlayerName.grid(row=1, column=1, columnspan=10) #experiment with columnspan

        # MLB Leaders label
        self.MLBLeadersLabel = Label(self.root, text="MLB Leaders")
        self.MLBLeadersLabel.grid(row=2, column=0)

        # buttons to right of MLB Leaders label
        self.HRButton = Button(self.root, text="HR", command=self.HRLeader)
        self.HRButton.grid(row=2, column=1)
        self.BAButton = Button(self.root, text="BA", command=self.BALeader)
        self.BAButton.grid(row=2, column=2)
        self.RBIButton = Button(self.root, text="RBI", command=self.RBILeader)
        self.RBIButton.grid(row=2, column=3)
        self.OPSButton = Button(self.root, text="OPS", command=self.OPSLeader)
        self.OPSButton.grid(row=2, column=4)
        self.OBPButton = Button(self.root, text="OBP", command=self.OBPLeader)
        self.OBPButton.grid(row=2, column=5)
        self.TripleButton = Button(self.root, text="Triple Crown", command=self.TripleLeader)
        self.TripleButton.grid(row=2, column=6)

    def fileSelect(self):
        
        # ask user to select file
        self.selectedFile = filedialog.askopenfilename()
        if self.selectedFile:
            aList = self.loadCSV(self.selectedFile)
        else:
            messagebox.showerror("Error", "No file selected. Please select a file.")

        self.setStringVar()

        # test if output list from loadCSV method can be parsed
        testerList = []
        try:
            for i in range(len(aList)):
                for j in range(len(aList[i])):
                    testerList.append(aList[i][j])
        except:
            messagebox.showerror("Error", "Something's wrong with the file you selected.")

        self.dataManipulator()

    def setStringVar(self):
        
        v = StringVar()
        v.set(self.selectedFile)
        g = v.get()
        self.entrySelectFile = Entry(self.root, width=60, state="readonly", textvariable=v)
        self.entrySelectFile.grid(row=0, column=1, columnspan=10)

        return g

    def loadCSV(self, filename):

        # read selected csv file from fileSelect method and check for errors in fileSelect method
        self.filename = filename
        try:
            csvlist = []
            f = open(self.filename)
            r = csv.reader(f, delimiter=",")
            for row in r:
                csvlist.append(row)
            f.close()
            csvlist.remove(csvlist[0])
        except:
            print("Something's wrong in the fileSelect method.")

        return csvlist

    def dataManipulator(self):

        # filter out players with less than 40 hits and remove first row
        fullList = self.loadCSV(self.setStringVar())
        aList = []
        i = 0
        while i <= len(fullList)-1:
            if (fullList[i][7] and fullList[i][9] and fullList[i][10] and fullList[i][11] and fullList[i][12] and fullList[i][13] and fullList[i][16] and fullList[i][19] and fullList[i][21] != "") and (int(fullList[i][9]) >= 40):
                aList.append(fullList[i])
                i += 1
            else:
                i += 1
                
        # calculate stats for BA, OBP, OPS, Triple Crown buttons
        # indexes to check: 7, 9, 10, 11, 12, 13, 16, 19, 21
        BAList = []
        for i in range(len(aList)):
            BA = int(aList[i][9])/int(aList[i][7])
            BAList.append(BA)
        
        OBPList = []
        for i in range(len(aList)):
            OBP = (int(aList[i][9]) + int(aList[i][16]) + int(aList[i][19]))/(int(aList[i][7]) + int(aList[i][16]) + int(aList[i][19]) + int(aList[i][21]))
            OBPList.append(OBP)
        
        OPSList = []
        for i in range(len(aList)):
            slugging = ((int(aList[i][9]) - int(aList[i][10]) - int(aList[i][11]) - int(aList[i][12])) + 2*int(aList[i][10]) + 3*int(aList[i][11]) + 4*int(aList[i][12]))/int(aList[i][7])
            OPS = OBPList[i] + slugging
            OPSList.append(OPS)
        
        TripleList = []
        HRLeader = 0
        HRList = []
        RBILeader = 0
        RBIList = []
        x = 0
        while x < len(aList):
            if int(aList[x][12]) > HRLeader:
                HRLeader = int(aList[x][12])
            if int(aList[x][13]) > RBILeader:
                RBILeader = int(aList[x][13])
            x += 1
        for i in range(len(aList)):
            HRList.append(int(aList[i][12]))
            RBIList.append(int(aList[i][13]))
        BALeader = 0
        for stat in BAList:
            if stat > BALeader:
                BALeader = stat
        for i in range(len(aList)):
            Triple = (HRLeader - int(aList[i][12])) + (RBILeader - int(aList[i][13])) + 100*(BALeader - BAList[i])
            TripleList.append(Triple)
            
        # save player names for each major stat
        self.dataDict = {}
        names = []
        for i in range(len(aList)):
            names.append(aList[i][1].lower())
        for i in range(len(names)):
            self.dataDict[names[i]] = [BAList[i]] + [OBPList[i]] + [OPSList[i]] + [HRList[i]] + [RBIList[i]] + [TripleList[i]]
            
    def searcher(self):

        aDict = self.dataDict
        
        # retrieve user input and store
        playerName = self.entryPlayerName.get()
        playerName = string.capwords(playerName)

        # find playerName averages, case insensitive
        if playerName.lower() in aDict:
            messagebox.showinfo("Player's Stats", playerName + "'s" + " stats are: " + str(aDict[playerName.lower()][0]) + " BA," + str(aDict[playerName.lower()][1]) + " OBP," + str(aDict[playerName.lower()][2]) + " OPS," + str(aDict[playerName.lower()][3]) + " HR," + str(aDict[playerName.lower()][4]) + " RBI")
        elif playerName.lower() + "*" in aDict:
            messagebox.showinfo("Player's Stats", playerName + "'s" + " stats are: " + str(aDict[playerName.lower() + "*"][0]) + " BA," + str(aDict[playerName.lower() + "*"][1]) + " OBP," + str(aDict[playerName.lower() + "*"][2]) + " OPS," + str(aDict[playerName.lower() + "*"][3]) + " HR," + str(aDict[playerName.lower() + "*"][4]) + " RBI")
        elif playerName.lower() + "#" in aDict:
            messagebox.showinfo("Player's Stats", playerName + "'s" + " stats are: " + str(aDict[playerName.lower() + "#"][0]) + " BA," + str(aDict[playerName.lower() + "#"][1]) + " OBP," + str(aDict[playerName.lower() + "#"][2]) + " OPS," + str(aDict[playerName.lower() + "#"][3]) + " HR," + str(aDict[playerName.lower() + "#"][4]) + " RBI")
        else:
            messagebox.showerror("Error", "Player not found in database, sorry!")

    def BALeader(self):

        dataDict = self.dataDict

        # find player with highest BA value in dataDict
        BALeader = 0
        BAName = ""
        for key, value in dataDict.items():
            if value[0] > BALeader:
                BALeader = value[0]
                BAName = string.capwords(key)

        messagebox.showinfo("Batting Average Leader", "The leader in batting average is " + BAName + "." + " His stats are:" + str(dataDict[BAName][0]) + " BA," + str(dataDict[BAName][1]) + " OBP," + str(dataDict[BAName][2]) + " OPS," + str(dataDict[BAName][3]) + " HR," + str(dataDict[BAName][4]) + " RBI")

    def HRLeader(self):

        dataDict = self.dataDict

        # find player with highest HR value in dataDict
        HRLeader = 0
        HRName = ""
        for key, value in dataDict.items():
            if value[3] > HRLeader:
                HRLeader = value[3]
                HRName = key

        messagebox.showinfo("Home Run Leader", "The leader in home runs is " + string.capwords(HRName) + "." + " His stats are:" + str(dataDict[HRName][0]) + " BA," + str(dataDict[HRName][1]) + " OBP," + str(dataDict[HRName][2]) + " OPS," +str(dataDict[HRName][3]) + " HR," + str(dataDict[HRName][4]) + " RBI")

    def RBILeader(self):

        dataDict = self.dataDict

        # find player with highest RBI value in dataDict
        RBILeader = 0
        RBIName = ""
        for key, value in dataDict.items():
            if value[4] > RBILeader:
                RBILeader = value[4]
                RBIName = key

        messagebox.showinfo("Runs Batted In Leader", "The leader in RBIs is " + string.capwords(RBIName) + "." + " His stats are:" + str(dataDict[RBIName][0]) + " BA," + str(dataDict[RBIName][1]) + " OBP," + str(dataDict[RBIName][2]) + " OPS," + str(dataDict[RBIName][3]) + " HR," + str(dataDict[RBIName][4]) + " RBI")

    def OBPLeader(self):

        dataDict = self.dataDict

        # find player with highest OBP value in dataDict
        OBPLeader = 0
        OBPName = ""
        for key, value in dataDict.items():
            if value[1] > OBPLeader:
                OBPLeader = value[1]
                OBPName = key

        messagebox.showinfo("On Base Percentage Leader", "The leader in OBP is " + string.capwords(OBPName) + "." + " His stats are:" + str(dataDict[OBPName][0]) + " BA," + str(dataDict[OBPName][1]) + " OBP," + str(dataDict[OBPName][2]) + " OPS," + str(dataDict[OBPName][3]) + " HR," + str(dataDict[OBPName][4]) + " RBI")

    def OPSLeader(self):

        dataDict = self.dataDict

        # find player with highest OPS value in dataDict
        OPSLeader = 0
        OPSName = ""
        for key, value in dataDict.items():
            if value[2] > OPSLeader:
                OPSLeader = value[2]
                OPSName = key

        messagebox.showinfo("On Base + Slugging Leader", "The leader in OPS is " + string.capwords(OPSName) + "." + " His stats are:" + str(dataDict[OPSName][0]) + " BA," + str(dataDict[OPSName][1]) + " OBP," + str(dataDict[OPSName][2]) + " OPS," + str(dataDict[OPSName][3]) + " HR," + str(dataDict[OPSName][4]) + " RBI")

    def TripleLeader(self):

        dataDict = self.dataDict

        # find player with lowest distance
        TripleLeader = 1000000
        TripleName = ""
        for key, value in dataDict.items():
            if value[5] < TripleLeader:
                TripleLeader = value[5]
                TripleName = key

        messagebox.showinfo("Triple Crown Pursuit", "The closest player to a Triple Crown is " + string.capwords(TripleName) + "." + " His stats are:" + str(dataDict[TripleName][0]) + " BA," + str(dataDict[TripleName][1]) + " OBP," + str(dataDict[TripleName][2]) + " OPS," + str(dataDict[TripleName][3]) + " HR," + str(dataDict[TripleName][4]) + " RBI")
                
        
rootWin = Tk()
app = HW04(rootWin)
rootWin.mainloop()

        
                
                                
                            

        
