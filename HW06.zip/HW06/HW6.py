# Jenny Li
# GTID 903108178
# jli639@gatech.edu
# I worked on this assignment alone using only this semester's course materials.
# Regarding Button 5, .png files will work with Tcl/Tk version 8.6+

import urllib.request
from re import findall
from tkinter import *

class HW06:

    def __init__(self, root):

        self.root = root
        self.GUI()
        
    def webScraper(self):

        # read webpage and convert its HTML to a single string
        request = urllib.request.Request("http://www.pgatour.com/leaderboard.html")
        response = urllib.request.urlopen(request)
        html = response.read()
        htmlString = html.decode()
        
        # find current/soonest event name
        findEvent = findall("/tournaments/.+\.html.+\s+.+</a>\s+<b class.+hidden-small sharing", htmlString) # this is a list
        eventString = findEvent[0]
        eventCrop = findall("(?<=\r\n).+(?=</a>\r\n)", eventString)
        event = eventCrop[0].strip()

        # find event duration
        findDuration = findall("<.+dates.+\s+.+\s+.+</span>", htmlString)
        durationString = findDuration[0]
        durationCrop1 = findall("(?<=\r\n).+(?=\r\n)", durationString)
        durationCrop2 = findall("(?<=\r\n).+(?=</span>)", durationString)
        duration = durationCrop1[0].strip() + " " + durationCrop2[0].strip()

        # find event purse
        findPurse = findall("<span.+purse.+Purse: \$[\d,]+</span>", htmlString)
        purseString = findPurse[0]
        purseCrop = findall("\$[\d,]+", purseString)
        purse = purseCrop[0]

        # find event location
        findLocation = findall("<.+course-info.+\s+.+\s+.+\s+.+name hidden-small.+\s.+</span>", htmlString)
        locationString = findLocation[0]
        locationCrop1 = findall('(?<="title hidden-small">).+(?=</span>\r\n)', locationString)
        locationCrop2 = findall('(?<="name hidden-small">\r\n).+(?=</span>)', locationString)
        location = locationCrop1[0] + ", " + locationCrop2[0].strip()

        # return data in a list so GUI can access it
        data = [event, duration, purse, location, locationCrop2[0].strip()]
        return data

    def getData(self):

        self.data = self.webScraper()

    def GUI(self):

        # title
        self.root.title("PGA Tour - Most Recent Event Overview")

        # Button 1 - trigger web scraper
        self.scrapeButton = Button(self.root, text="Get Data", command=self.getData)
        self.scrapeButton.grid(row=0, column=0, columnspan=4)

        # Button 2 - display data in Toplevel window
        self.tlButton = Button(self.root, text="Display in Toplevel", command=self.goToTL)
        self.tlButton.grid(row=1, column=0)

        # Button 3 - display data in messagebox
        self.mbButton = Button(self.root, text="Display in Messagebox", command=self.goToMB)
        self.mbButton.grid(row=1, column=1)

        # Button 4 - display data in readonly entries
        self.entryButton = Button(self.root, text="Display in Readonly Entries", command=self.goToEntry)
        self.entryButton.grid(row=1, column=2)
        self.nl = Label(self.root, text="Event Name: ")
        self.nl.grid(row=4, column=0, columnspan=2)
        self.name = Entry(self.root, width=50, state="readonly")
        self.name.grid(row=4, column=2, columnspan=2)
        self.dl = Label(self.root, text="Event Duration: ")
        self.dl.grid(row=5, column=0, columnspan=2)
        self.duration = Entry(self.root, width=50, state="readonly")
        self.duration.grid(row=5, column=2, columnspan=2)
        self.pl = Label(self.root, text="Event Purse: ")
        self.pl.grid(row=6, column=0, columnspan=2)
        self.purse = Entry(self.root, width=50, state="readonly")
        self.purse.grid(row=6, column=2, columnspan=2)
        self.ll = Label(self.root, text="Event Location: ")
        self.ll.grid(row=7, column=0, columnspan=2)
        self.location = Entry(self.root, width=50, state="readonly")
        self.location.grid(row=7, column=2, columnspan=2)
        
        # Button 5 - display data with Google Static Maps API
        self.mapButton = Button(self.root, text="Display Map", command=self.goToMap)
        self.mapButton.grid(row=1, column=3)

    def goToTL(self):

        # helper for Button 2
        self.root.withdraw()
        self.tlWindow()

    def tlWindow(self):

        # for Button 2
        self.tlWin = Toplevel()
        self.tlWin.title("Event Information")
        self.tlname = Label(self.tlWin, text="Event Name: " + self.data[0])
        self.tlname.grid(row=0, column=0)
        self.tlduration = Label(self.tlWin, text="Event Duration: " + self.data[1])
        self.tlduration.grid(row=1, column=0)
        self.tlpurse = Label(self.tlWin, text="Event Purse: " + self.data[2])
        self.tlpurse.grid(row=2, column=0)
        self.tllocation = Label(self.tlWin, text="Event Location: " + self.data[3])
        self.tllocation.grid(row=3, column=0)
        self.back2 = Button(self.tlWin, text="Back", command=self.back2)
        self.back2.grid(row=4, column=0)

    def back2(self):

        # helper for Button 2
        self.tlWin.withdraw()
        self.root.deiconify()

    def goToMB(self):

        # for Button 3
        messagebox.showinfo("Event Information", "Event Name: " + self.data[0] + "\nEvent Duration: " + self.data[1] + "\nEvent Purse: " + self.data[2] + "\nEvent Location: " + self.data[3])

    def goToEntry(self):

        # for Button 4
        self.vn = StringVar()
        self.vn.set(self.data[0])
        self.name = Entry(self.root, width=50, state="readonly", textvariable=self.vn)
        self.name.grid(row=4, column=2, columnspan=2)
        self.vd = StringVar()
        self.vd.set(self.data[1])
        self.duration = Entry(self.root, width=50, state="readonly", textvariable=self.vd)
        self.duration.grid(row=5, column=2, columnspan=2)
        self.vp = StringVar()
        self.vp.set(self.data[2])
        self.purse = Entry(self.root, width=50, state="readonly", textvariable=self.vp)
        self.purse.grid(row=6, column=2, columnspan=2)
        self.vl = StringVar()
        self.vl.set(self.data[3])
        self.location = Entry(self.root, width=50, state="readonly", textvariable=self.vl)
        self.location.grid(row=7, column=2, columnspan=2)

    def goToMap(self):

        # helper for Button 5
        self.root.withdraw()
        self.staticMap()

    def staticMap(self):

        # for Button 5
        locSpaces = self.data[4]
        loc = locSpaces.replace(" ", "+")
        staticURL = "https://maps.googleapis.com/maps/api/staticmap?center=" + loc + "&zoom=9&size=640x640&key=AIzaSyDH5IYBahJVxSUjX-mDLBNYyXPf4Qq2-p4"
##        imgrsc = urllib.request.urlopen(staticURL)
##        imgsave = open("eventmap.GIF", "wb")    # eventmap.jpg contains map image
##        imgsave.write(imgrsc.read())
##        imgsave.close()
        urllib.request.urlretrieve(staticURL, filename="eventmap.png")
##        i = open("eventmap.GIF", "rb")
##        idata = i.read()
##        i.close()
        i = PhotoImage(file="eventmap.png")
        self.imageWin = Toplevel()
        self.imageWin.title(self.data[0] + ", " + self.data[1] + ", Purse: " + self.data[2])
        self.imageLabel = Label(self.imageWin, image=i)
        self.imageLabel.grid(row=0, column=0)
        self.back5 = Button(self.imageWin, text="Back", command=self.back5)
        self.back5.grid(row=1, column=0)

    def back5(self):

        # helper for Button 5
        self.imageWin.withdraw()
        self.root.deiconify()

rootWin = Tk()
app = HW06(rootWin)
rootWin.mainloop()
