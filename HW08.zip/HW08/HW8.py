# Jenny Li
# GTID 903108178
# jli639@gatech.edu
# I worked on this assignment alone using only this semester's course materials.

import pymysql
from tkinter import *
from tkinter import messagebox
import re
import datetime

class forum:

    def __init__(self, root):

        self.root = root
        self.rootWindow()
        
    def connect(self):
        
        self.db = pymysql.connect(host="academic-mysql.cc.gatech.edu", passwd="bTRHJ939", user="jli639", db="cs2316db")
        return self.db

    def rootWindow(self):

        self.root.title("GTChat Login")
        self.username = Label(self.root, text="Username:")
        self.username.grid(row=0, column=0, sticky=E)
        self.password = Label(self.root, text="Password:")
        self.password.grid(row=1, column=0, sticky=E)
        self.usernameEntry = Entry(self.root, width=30)
        self.usernameEntry.grid(row=0, column=1, columnspan=3)
        self.passwordEntry = Entry(self.root, width=30)
        self.passwordEntry.grid(row=1, column=1, columnspan=3)
        self.register = Button(self.root, text="Register", command=self.registerWindow)
        self.register.grid(row=2, column=3, sticky=W)
        self.login = Button(self.root, text="Login", command=self.login)
        self.login.grid(row=2, column=3, sticky=E)

    def login(self):
        
        self.un = self.usernameEntry.get()
        self.pw = self.passwordEntry.get()
        self.connect()
        cursor = self.db.cursor()
        sql = "SELECT * FROM GTForumUsers WHERE username=%s AND password=%s"
        cursor.execute(sql, (self.un, self.pw))
        if cursor.rowcount == 0:
            messagebox.showwarning("Login Failed", "Check username and password.")
        else:
            messagebox.showinfo("Login Successful", "You have been logged in.")
            cursor.close()
            self.db.close()
            self.toChat()

    def registerWindow(self):

        self.root.withdraw()
        self.reg = Toplevel()
        self.reg.title("GTChat Register")
        self.fullname = Label(self.reg, text="Full Name:")
        self.fullname.grid(row=0, column=0, sticky=E)
        self.unlabel = Label(self.reg, text="Username:")
        self.unlabel.grid(row=1, column=0, sticky=E)
        self.pwlabel = Label(self.reg, text="Password:")
        self.pwlabel.grid(row=2, column=0, sticky=E)
        self.confirm = Label(self.reg, text="Confirm Password:")
        self.confirm.grid(row=3, column=0, sticky=E)
        self.fullnameEntry = Entry(self.reg, width=30)
        self.fullnameEntry.grid(row=0, column=1, columnspan=3)
        self.unlabelEntry = Entry(self.reg, width=30)
        self.unlabelEntry.grid(row=1, column=1, columnspan=3)
        self.pwlabelEntry = Entry(self.reg, width=30)
        self.pwlabelEntry.grid(row=2, column=1, columnspan=3)
        self.confirmEntry = Entry(self.reg, width=30)
        self.confirmEntry.grid(row=3, column=1, columnspan=3)
        self.cancel = Button(self.reg, text="Cancel", command=self.cancelButton)
        self.cancel.grid(row=4, column=3, sticky=W)
        self.sub = Button(self.reg, text="Submit", command=self.regis)
        self.sub.grid(row=4, column=3, sticky=E)
        
    def regis(self):

        self.connect()
        cursor = self.db.cursor()
        newUser = "INSERT INTO GTForumUsers VALUES (%s, %s, %s)"
        sql = "SELECT * FROM GTForumUsers WHERE username=%s"
        cursor.execute(sql, (self.unlabelEntry.get()))
        if self.unlabelEntry.get() == "":
            messagebox.showwarning("Invalid Username", "Username cannot be blank.")
            return
        if cursor.rowcount != 0:
            messagebox.showwarning("Invalid Username", "Username already in use.")
            return
        if re.search("[A-Z]", self.pwlabelEntry.get()) is None or re.search("\d", self.pwlabelEntry.get()) is None:
            messagebox.showwarning("Invalid Password", "Password must have at least one digit and one uppercase letter.")
            return
        if self.pwlabelEntry.get() != self.confirmEntry.get():
            messagebox.showwarning("Password Error", "Passwords do not match.")
            return
        
        if self.fullnameEntry.get() == "":
            self.nullname = None
            cursor.execute(newUser, (self.unlabelEntry.get(), self.nullname, self.pwlabelEntry.get()))
            self.db.commit()
        else:
            cursor.execute(newUser, (self.unlabelEntry.get(), self.fullnameEntry.get(), self.pwlabelEntry.get()))
            self.db.commit()

        messagebox.showinfo("Registration", "You registered successfully.")
        cursor.close()
        self.db.close()
        self.cancelButton()

    def toChat(self):

        self.root.withdraw()
        self.chatWindow()

    def cancelButton(self):

        self.reg.withdraw()
        self.root.deiconify()

    def logoutButton(self):

        self.chat.withdraw()
        self.root.deiconify()

    def updateMainPage(self):

        top = StringVar()
        self.connect()
        cursor = self.db.cursor()
        sql = "SELECT user, COUNT(*) FROM GTForumPosts GROUP BY user ORDER BY COUNT(*) DESC"
        cursor.execute(sql)
        l = []
        for each in cursor:
            l.append(each)
        self.longstr = "Top Users: " + l[0][0] + ", " + str(l[0][1]) + " posts  " + l[1][0] + ", " + str(l[1][1]) + " posts  " + l[2][0] + ", " + str(l[2][1]) + " posts  "
        top.set(self.longstr)
        self.topUsersArea = Label(self.chat, bd=5, textvariable=top)
        self.topUsersArea.grid(row=0, column=0, columnspan=5)

        mg = StringVar()
        time = "SELECT * FROM GTForumPosts ORDER BY id DESC LIMIT 10"
        cursor.execute(time)
        t = []
        for each in cursor:
            t.append(each)
        msgs = []
        for post in t:
            line = post[2] + ": " + post[1] + " Created at " + post[3] + "\n"
            msgs.append(line)
        self.m = ""
        for i in range(len(msgs) - 1):
            self.m += msgs[i]
        mg.set(self.m)
        self.messageArea = Label(self.chat, bd=5, relief=SUNKEN, textvariable=mg)
        self.messageArea.grid(row=1, column=0, columnspan=5)

        cursor.close()
        self.db.close()
     
    def chatWindow(self):

        self.top = StringVar()
        self.mg = StringVar()
        self.chat = Toplevel()
        self.chat.title("GTForum")
        self.typePost = Entry(self.chat, width=30)
        self.typePost.grid(row=2, column=2, sticky=E)
        self.submitPost = Button(self.chat, text="Submit Post", command=self.submitPost)
        self.submitPost.grid(row=2, column=3, sticky=E)
        self.logout = Button(self.chat, text="Log Out", command=self.logoutButton)
        self.logout.grid(row=2, column=4)
        self.updateMainPage()

    def submitPost(self):

        self.post = self.typePost.get()
        self.connect()
        cursor = self.db.cursor()
        sql = "INSERT INTO GTForumPosts (user, messageText, timestamp) VALUES (%s, %s, %s)"
        timestamp = '{:%m-%d-%Y %H:%M:%S}'.format(datetime.datetime.now())
        
        if self.post == "":
            return
        else:
            cursor.execute(sql, (self.un, self.post, timestamp))
            self.db.commit()

        cursor.close()
        self.db.close()
        self.updateMainPage()       

rootWin = Tk()
app = forum(rootWin)
rootWin.mainloop()
        


